
### Demo of Swagger UI with Webpack.

This `webpack-getting-started` sample is for reference only.

It includes CSS and OAuth configuration.

`_sample_package.json` is a placeholder sample. You should rename this file, per `Usage` section below, and you should also verify and update this sample's `@latest` compared to the `swagger-ui@latest`


#### Usage
    rename `_sample_package.json` to `package.json`
    npm install
    npm start
