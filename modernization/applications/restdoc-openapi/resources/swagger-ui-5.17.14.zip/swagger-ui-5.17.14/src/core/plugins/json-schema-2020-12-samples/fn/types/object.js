/**
 * @prettier
 */

const objectType = () => {
  throw new Error("Not implemented")
}

export default objectType
